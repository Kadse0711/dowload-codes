(function ($) {
    $(document).ready(function () {
        var $fileSource = $('#file_source');
        function toggleFileSourceRows() {
            var internal = $fileSource.val() === 'internal';
            $('#remote_file_row').toggle(!internal);
            $('#internal_file_row').toggle(internal);
            $('#remote_link').prop('required', !internal);
            $('#internal_file').prop('required', internal);
        }
        $fileSource.on('change', toggleFileSourceRows);
        toggleFileSourceRows();

        var $methodSelect = $('#ndm_upload_method');
        function toggleConnectionRows() {
            var method = $methodSelect.val();
            $('.ndm-local-settings').toggle(method === 'local');
            $('.ndm-ftp-settings').toggle(method === 'ftp');
            $('.ndm-file-station-settings').toggle(method === 'file_station');
        }
        $methodSelect.on('change', toggleConnectionRows);
        toggleConnectionRows();

        $('#ndm_upload_dir_select').on('change', function () {
            var selected = $(this).val();
            if (selected) {
                $('#ndm_upload_path').val(selected + '/');
            }
        });

        $('#ndm_local_dir_select').on('change', function () {
            var selected = $(this).val();
            if (selected) {
                $('#ndm_default_upload_path').val(selected);
            }
        });

        $('#ndm_upload_local_path_select').on('change', function () {
            var selected = $(this).val();
            if (selected) {
                $('#ndm_upload_path').val(selected);
            }
        });

        $('#ndm_local_path_select').on('change', function () {
            var selected = $(this).val();
            if (selected) {
                $('#ndm_download_root').val(selected);
            }
        });
    });
})(jQuery);
