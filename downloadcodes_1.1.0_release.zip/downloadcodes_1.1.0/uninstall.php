<?php
if (!defined('WP_UNINSTALL_PLUGIN')) { exit; }

global $wpdb;
$table_codes = $wpdb->prefix . 'ndm_downloads';
$table_logs = $wpdb->prefix . 'ndm_download_logs';
$table_uploads = $wpdb->prefix . 'ndm_download_uploads';
$wpdb->query('DROP TABLE IF EXISTS ' . $table_codes);
$wpdb->query('DROP TABLE IF EXISTS ' . $table_logs);
$wpdb->query('DROP TABLE IF EXISTS ' . $table_uploads);

// Remove options
delete_option('ndm_upload_method');
delete_option('ndm_download_root');
delete_option('ndm_download_page_url');
delete_option('ndm_internal_storage_root');
delete_option('ndm_default_upload_path');
delete_option('ndm_ftp_host');
delete_option('ndm_ftp_port');
delete_option('ndm_ftp_ssl');
delete_option('ndm_ftp_username');
delete_option('ndm_ftp_password');
delete_option('ndm_ftp_root');
delete_option('ndm_file_station_url');
delete_option('ndm_file_station_username');
delete_option('ndm_file_station_password');
delete_option('ndm_file_station_root');
delete_option('ndm_sender_name');
delete_option('ndm_sender_email');
delete_option('ndm_email_subject');
delete_option('ndm_email_body');
delete_option('ndm_email_html');
delete_option('ndm_email_template_1_name');
delete_option('ndm_email_template_1_subject');
delete_option('ndm_email_template_1_body');
delete_option('ndm_email_template_2_name');
delete_option('ndm_email_template_2_subject');
delete_option('ndm_email_template_2_body');
