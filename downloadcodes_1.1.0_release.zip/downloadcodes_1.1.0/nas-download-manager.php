<?php
/**
 * Plugin Name: NAS Download Manager
 * Plugin URI: https://hover-media.com
 * Description: Sicherer Download-Manager für Remote-Links und interne Dateien mit Downloadcodes.
 * Version: 1.1.1
 * Author: Hover Media
 * Author URI: https://hover-media.com
 * Requires PHP: 7.0
 * Requires at least: 7.0
 * Tested up to: 6.9
 * License: GPL v2 or later
 * Text Domain: nas-download-manager
 * Update URI: https://github.com/Kadse0711/dowload-codes
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!defined('NDM_VERSION')) {
    define('NDM_VERSION', '1.1.1');
}

if (!defined('NDM_PLUGIN_PATH')) {
    define('NDM_PLUGIN_PATH', plugin_dir_path(__FILE__));
}

if (!defined('NDM_PLUGIN_URL')) {
    define('NDM_PLUGIN_URL', plugin_dir_url(__FILE__));
}

require_once NDM_PLUGIN_PATH . 'includes/class-loader.php';
require_once NDM_PLUGIN_PATH . 'includes/class-github-updater.php';

NDM_GitHub_Updater::init();

register_activation_hook(__FILE__, array('NDM_Loader', 'activate'));
register_deactivation_hook(__FILE__, array('NDM_Loader', 'deactivate'));
add_action('plugins_loaded', array('NDM_Loader', 'init'));