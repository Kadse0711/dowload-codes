<?php

if (!defined('ABSPATH')) {
    exit;
}

class NDM_GitHub_Updater {
    const REPOSITORY = 'Kadse0711/dowload-codes';

    public static function init() {
        add_filter('pre_set_site_transient_update_plugins', array(__CLASS__, 'check_for_update'));
        add_filter('plugins_api', array(__CLASS__, 'plugin_information'), 10, 3);
    }

    public static function check_for_update($transient) {
        if (!is_object($transient)) {
            $transient = new stdClass();
        }

        $release = self::get_latest_release();
        if (!$release || empty($release->tag_name)) {
            return $transient;
        }

        $new_version = ltrim($release->tag_name, 'vV');
        if (version_compare(NDM_VERSION, $new_version, '>=')) {
            return $transient;
        }

        $plugin_file = plugin_basename(dirname(__DIR__) . '/nas-download-manager.php');
        $update = new stdClass();
        $update->slug = dirname($plugin_file);
        $update->plugin = $plugin_file;
        $update->new_version = $new_version;
        $update->url = !empty($release->html_url) ? $release->html_url : 'https://github.com/' . self::REPOSITORY;
        $update->package = self::get_package_url($release);

        if ($update->package) {
            $transient->response[$plugin_file] = $update;
        }

        return $transient;
    }

    public static function plugin_information($result, $action, $args) {
        if ('plugin_information' !== $action || empty($args->slug)) {
            return $result;
        }

        $plugin_file = plugin_basename(dirname(__DIR__) . '/nas-download-manager.php');
        if (dirname($plugin_file) !== $args->slug) {
            return $result;
        }

        $release = self::get_latest_release();
        if (!$release) {
            return $result;
        }

        $information = new stdClass();
        $information->name = 'NAS Download Manager';
        $information->slug = dirname($plugin_file);
        $information->version = ltrim($release->tag_name, 'vV');
        $information->author = '<a href="https://hover-media.com">Hover Media</a>';
        $information->homepage = 'https://github.com/' . self::REPOSITORY;
        $information->download_link = self::get_package_url($release);
        $information->sections = array(
            'description' => 'Neue Version des NAS Download Manager aus dem GitHub-Repository.',
            'changelog' => !empty($release->body) ? nl2br(esc_html($release->body)) : 'Keine Änderungshinweise vorhanden.',
        );

        return $information;
    }

    private static function get_latest_release() {
        $response = wp_remote_get(
            'https://api.github.com/repos/' . self::REPOSITORY . '/releases/latest',
            array(
                'timeout' => 10,
                'headers' => array(
                    'Accept' => 'application/vnd.github+json',
                    'User-Agent' => 'NAS-Download-Manager/' . NDM_VERSION,
                ),
            )
        );

        if (is_wp_error($response) || 200 !== wp_remote_retrieve_response_code($response)) {
            return false;
        }

        $release = json_decode(wp_remote_retrieve_body($response));
        return is_object($release) && !empty($release->tag_name) ? $release : false;
    }

    private static function get_package_url($release) {
        if (!empty($release->assets) && is_array($release->assets)) {
            foreach ($release->assets as $asset) {
                if (!empty($asset->name) && '.zip' === strtolower(substr($asset->name, -4)) && !empty($asset->browser_download_url)) {
                    return $asset->browser_download_url;
                }
            }
        }

        return !empty($release->zipball_url) ? $release->zipball_url : false;
    }
}