<?php

if (!defined('ABSPATH')) {
    exit;
}

class NDM_Download {
    public static function handle_request() {
        try {
            $code = '';
            if (!empty($_GET['code'])) {
                $code = NDM_Security::sanitize_code($_GET['code']);
            } elseif (function_exists('get_query_var')) {
                $code = NDM_Security::sanitize_code(get_query_var('code'));
            }

            $file_key = '';
            if (!empty($_GET['file'])) {
                $file_key = sanitize_text_field($_GET['file']);
            } elseif (function_exists('get_query_var')) {
                $file_key = sanitize_text_field(get_query_var('file'));
            }

            if (empty($code)) {
                self::send_error('Fehlender Downloadcode.');
            }

            $code_data = NDM_Database::get_code_by_code($code);
            if (empty($code_data) || $code_data['status'] !== 'active') {
                self::send_error('Ungültiger oder inaktiver Downloadcode.');
            }

            if (!empty($code_data['expires']) && strtotime($code_data['expires']) < current_time('timestamp')) {
                self::log_attempt($code_data, $file_key, 0, 'Code abgelaufen');
                self::send_error('Dieser Downloadcode ist abgelaufen.');
            }

            if (isset($code_data['max_downloads']) && intval($code_data['max_downloads']) > 0 && intval($code_data['downloads']) >= intval($code_data['max_downloads'])) {
                self::log_attempt($code_data, $file_key, 0, 'Download-Limit erreicht');
                self::send_error('Dieses Downloadlimit wurde erreicht.');
            }

            $files = NDM_Database::normalize_files(isset($code_data['files']) ? $code_data['files'] : array());
            if (empty($files)) {
                self::send_error('Keine Dateien für diesen Code hinterlegt.');
            }

            if ($file_key === '') {
                if (count($files) === 1) {
                    $single_file = $files[0];
                    $file_relative = NDM_Database::get_file_url($single_file);
                    if (preg_match('/^https?:\/\//i', $file_relative)) {
                        self::log_attempt($code_data, $file_relative, 1, 'Remote-URL weitergeleitet');
                        NDM_Database::incr_downloads($code_data['id']);
                        wp_redirect(esc_url_raw($file_relative));
                        exit;
                    }
                    self::serve_file($code_data, $file_relative);
                }
                self::serve_code_selection_page($code_data);
            }

            $file_key = NDM_Security::sanitize_file_key($file_key);
            if ($file_key === '' || !ctype_digit($file_key)) {
                self::send_error('Ungültiger Dateischlüssel.');
            }

            $index = intval($file_key);
            if (!isset($files[$index])) {
                self::send_error('Ausgewählte Datei nicht gefunden.');
            }

            $file_entry = $files[$index];
            $file_relative = NDM_Database::get_file_url($file_entry);
            if (preg_match('/^https?:\/\//i', $file_relative)) {
                self::log_attempt($code_data, $file_relative, 1, 'Remote-URL weitergeleitet');
                NDM_Database::incr_downloads($code_data['id']);
                wp_redirect(esc_url_raw($file_relative));
                exit;
            }

            self::serve_file($code_data, $file_relative);
        } catch (Exception $e) {
            self::log_exception($e, $code_data ?? array());
            self::send_error('Der Download konnte nicht verarbeitet werden.');
        }
    }

    protected static function log_exception($e, $code_data) {
        $message = 'NDM download error: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine();
        if (defined('WP_DEBUG_LOG') && WP_DEBUG_LOG) {
            error_log($message);
        } else {
            error_log($message);
        }
        if (!empty($code_data)) {
            self::log_attempt($code_data, '', 0, 'Interner Fehler');
        }
    }

    protected static function get_download_page_url() {
        $custom_url = trim(get_option('ndm_download_page_url', ''));
        if (!empty($custom_url) && filter_var($custom_url, FILTER_VALIDATE_URL)) {
            return untrailingslashit($custom_url);
        }
        return home_url('/');
    }

    protected static function serve_code_selection_page($code_data) {
        $items = '';
        $index = 0;
        $base_url = self::get_download_page_url();
        foreach ($code_data['files'] as $file_entry) {
            $download_url = esc_url(add_query_arg(array('ndm_download' => 1, 'code' => $code_data['code'], 'file' => $index), $base_url));
            $label = NDM_Database::get_file_name($file_entry);
            $items .= '<li><a href="' . $download_url . '">' . esc_html($label) . '</a></li>';
            $index += 1;
        }

        $output = '<!DOCTYPE html><html><head><meta charset="utf-8"><title>Downloadcode ' . esc_html($code_data['code']) . '</title>';
        $output .= '<style>body{font-family:Arial,sans-serif;background:#f7f7f7;color:#222;padding:2rem;} .ndm-download-box{max-width:720px;margin:0 auto;background:#fff;padding:1.5rem;border:1px solid #ddd;border-radius:8px;} .ndm-download-box h1{margin-top:0;} .ndm-download-box ul{list-style:none;padding:0;} .ndm-download-box li{margin:0.75rem 0;} .ndm-download-box a{color:#21759b;text-decoration:none;}</style>';
        $output .= '</head><body><div class="ndm-download-box"><h1>Downloadcode: ' . esc_html($code_data['code']) . '</h1>';
        $output .= '<p>Wähle eine Datei zum Download:</p><ul>' . $items . '</ul>';
        $output .= '</div></body></html>';

        echo $output;
        exit;
    }

    protected static function serve_file($code_data, $relative) {
        $file_name = basename(preg_replace('#^local:#i', '', (string) $relative));
        $mime = wp_check_filetype($file_name);
        $mime_type = !empty($mime['type']) ? $mime['type'] : 'application/octet-stream';

        if (headers_sent()) {
            self::send_error('Die Download-Antwort konnte nicht gesendet werden.');
        }

        nocache_headers();
        status_header(200);

        header('Content-Description: File Transfer');
        header('Content-Type: ' . esc_html($mime_type));
        header('Content-Disposition: attachment; filename="' . rawurlencode($file_name) . '"');
        header('Content-Transfer-Encoding: binary');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');

        if (ob_get_level()) {
            ob_end_clean();
        }

        $result = NDM_Uploader::stream_file($relative);
        if (is_wp_error($result)) {
            self::log_attempt($code_data, $relative, 0, $result->get_error_message());
            self::send_error($result->get_error_message());
        }

        NDM_Database::incr_downloads($code_data['id']);
        self::log_attempt($code_data, $relative, 1, 'Download gestartet');
        exit;
    }

    protected static function log_attempt($code_data, $file_path, $success, $message) {
        NDM_Database::log_download(array(
            'code_id' => isset($code_data['id']) ? intval($code_data['id']) : null,
            'code' => isset($code_data['code']) ? $code_data['code'] : null,
            'file_path' => $file_path,
            'user_id' => get_current_user_id(),
            'ip' => isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field($_SERVER['REMOTE_ADDR']) : null,
            'user_agent' => isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field($_SERVER['HTTP_USER_AGENT']) : null,
            'success' => intval($success),
            'message' => sanitize_text_field($message),
        ));
    }

    protected static function send_error($message) {
        wp_die(esc_html($message), 'NAS Download Manager', array('response' => 400));
    }
}

