<?php
if (!defined('ABSPATH')) {
    exit;
}

class NDM_Uploader {
    public static function get_upload_method() {
        return 'internal';
    }

    public static function upload_file(array $file, $destination) {
        if (empty($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
            return new WP_Error('invalid_upload', 'Die interne Datei konnte nicht gelesen werden.');
        }

        $root = self::get_storage_root();
        if (!wp_mkdir_p($root) || !NDM_Security::is_valid_download_root($root)) {
            return new WP_Error('invalid_storage_root', 'Der interne Speicherpfad ist nicht verfügbar.');
        }

        $name = sanitize_file_name(!empty($file['name']) ? $file['name'] : 'download');
        $relative = trim(str_replace('\\', '/', (string) $destination), '/');
        $relative = $relative !== '' ? $relative . '/' . $name : $name;
        $target = self::get_local_path('local:' . $relative);
        if (empty($target)) {
            return new WP_Error('invalid_destination', 'Ungültiger interner Speicherpfad.');
        }

        wp_mkdir_p(dirname($target));
        if (!move_uploaded_file($file['tmp_name'], $target)) {
            return new WP_Error('upload_failed', 'Die Datei konnte nicht gespeichert werden.');
        }

        return 'local:' . $relative;
    }

    public static function stream_file($relative_path) {
        if (preg_match('/^https?:\/\//i', $relative_path)) {
            $response = wp_remote_get($relative_path, array('timeout' => 120, 'sslverify' => false));
            if (is_wp_error($response)) {
                return new WP_Error('remote_download_failed', $response->get_error_message());
            }

            $status_code = intval(wp_remote_retrieve_response_code($response));
            if ($status_code >= 400) {
                return new WP_Error('remote_download_failed', 'Die Remote-Datei konnte nicht geladen werden.');
            }

            $body = wp_remote_retrieve_body($response);
            if ($body === '') {
                return new WP_Error('remote_download_failed', 'Die Remote-Datei konnte nicht gelesen werden.');
            }

            echo $body;
            return true;
        }

        $local_path = self::get_local_path($relative_path);
        if (empty($local_path) || !is_file($local_path) || !is_readable($local_path)) {
            return new WP_Error('local_file_missing', 'Die interne Datei ist nicht verfügbar.');
        }

        $handle = fopen($local_path, 'rb');
        if (!$handle) {
            return new WP_Error('local_file_unreadable', 'Die interne Datei konnte nicht geöffnet werden.');
        }
        while (!feof($handle)) {
            echo fread($handle, 8192);
        }
        fclose($handle);
        return true;
    }

    public static function get_storage_root() {
        $configured = trim((string) get_option('ndm_internal_storage_root', ''));
        if ($configured !== '') {
            return untrailingslashit($configured);
        }
        $uploads = wp_upload_dir();
        return untrailingslashit($uploads['basedir']);
    }

    protected static function get_local_path($relative_path) {
        $relative_path = preg_replace('#^local:#i', '', (string) $relative_path);
        $relative_path = str_replace('\\', '/', $relative_path);
        if ($relative_path === '' || preg_match('#(^|/)\.\.(/|$)#', $relative_path) || preg_match('#^([A-Za-z]:|/)#', $relative_path)) {
            return '';
        }

        $root = self::get_storage_root();
        $path = $root . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, ltrim($relative_path, '/'));
        $parent = realpath(dirname($path));
        if ($parent === false || !NDM_Security::is_path_in_root($root, $parent . DIRECTORY_SEPARATOR)) {
            return '';
        }
        return $path;
    }
}
