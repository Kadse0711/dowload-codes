<?php
if (!defined('ABSPATH')) { exit; }

class NDM_Security {
    public static function sanitize_code($code) {
        $code = preg_replace('/[^A-Za-z0-9\-]/', '', (string) $code);
        return strtoupper(trim($code));
    }

    public static function sanitize_file_key($key) {
        return preg_replace('/[^0-9a-zA-Z_\-]/', '', (string) $key);
    }

    public static function normalize_path($path) {
        $path = str_replace('\\', '/', $path);
        $parts = explode('/', $path);
        $out = array();
        foreach ($parts as $part) {
            if ($part === '' || $part === '.') { continue; }
            if ($part === '..') { array_pop($out); continue; }
            $out[] = $part;
        }
        return implode(DIRECTORY_SEPARATOR, $out);
    }

    public static function is_path_in_root($root, $path) {
        $root_norm = self::normalize_path(trailingslashit($root));
        $path_norm = self::normalize_path($path);
        // Ensure both use same separators
        $root_norm = str_replace(array('\\','/'), DIRECTORY_SEPARATOR, $root_norm);
        $path_norm = str_replace(array('\\','/'), DIRECTORY_SEPARATOR, $path_norm);
        return strpos($path_norm, $root_norm) === 0;
    }

    public static function is_valid_download_root($root) {
        if (empty($root)) { return false; }
        $root = rtrim($root, "\\/");
        return is_dir($root) && is_readable($root);
    }

    public static function list_files_recursive($root, $search) {
        $items = array();
        if (!self::is_valid_download_root($root)) { return $items; }
        $root = rtrim($root, "\\/") . DIRECTORY_SEPARATOR;
        $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS));
        foreach ($it as $file) {
            if ($file->isFile()) {
                $rel = substr($file->getPathname(), strlen($root));
                if (!empty($search) && stripos($rel, $search) === false) { continue; }
                $items[] = array('relative' => str_replace('\\', '/', $rel), 'size' => $file->getSize(), 'modified' => date('Y-m-d H:i:s', $file->getMTime()), 'type' => pathinfo($rel, PATHINFO_EXTENSION));
            }
        }
        return $items;
    }

    public static function list_directories_recursive($root) {
        $items = array();
        if (!self::is_valid_download_root($root)) { return $items; }
        $root = rtrim($root, "\\/") . DIRECTORY_SEPARATOR;
        $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::SELF_FIRST);
        foreach ($it as $file) {
            if ($file->isDir()) {
                $rel = substr($file->getPathname(), strlen($root));
                $parts = explode(DIRECTORY_SEPARATOR, $rel);
                $items[] = str_replace('\\', '/', implode('/', $parts));
            }
        }
        sort($items);
        return array_values(array_unique($items));
    }

    public static function list_available_local_paths($root = '') {
        $candidates = array();
        $configured = trim((string) $root);
        if (!empty($configured)) {
            $candidates[] = $configured;
        }

        if (defined('PHP_OS_FAMILY') && PHP_OS_FAMILY === 'Windows') {
            foreach (range('C', 'Z') as $drive) {
                $candidates[] = $drive . ':';
                $candidates[] = $drive . ':\\';
            }
        } else {
            $candidates[] = '/';
            $candidates[] = '/mnt';
            $candidates[] = '/media';
            $candidates[] = '/volume1';
            $candidates[] = '/share';
            $candidates[] = '/home';
            $candidates[] = '/srv';
            $candidates[] = '/var';
            $candidates[] = '/opt';
            $candidates[] = '/tmp';
        }

        $items = array();
        foreach ($candidates as $candidate) {
            if (empty($candidate)) {
                continue;
            }
            $candidate = str_replace(array('\\', '/'), DIRECTORY_SEPARATOR, trim($candidate));
            $resolved = realpath($candidate);
            if ($resolved !== false && is_dir($resolved) && is_readable($resolved)) {
                $items[] = $resolved;
            }
        }

        $discovered = array();
        foreach ($items as $item) {
            if (!in_array($item, $discovered, true)) {
                $discovered[] = $item;
            }
            if (!is_dir($item) || !is_readable($item)) {
                continue;
            }
            try {
                $iterator = new DirectoryIterator($item);
                foreach ($iterator as $entry) {
                    if ($entry->isDot() || !$entry->isDir()) {
                        continue;
                    }
                    $name = $entry->getFilename();
                    if (substr($name, 0, 1) === '.') {
                        continue;
                    }
                    $child = $entry->getPathname();
                    if (is_readable($child) && !in_array($child, $discovered, true)) {
                        $discovered[] = $child;
                    }
                }
            } catch (Exception $e) {
                continue;
            }
        }

        sort($discovered, SORT_STRING);
        return array_values(array_unique($discovered));
    }
}
