<?php
if (!defined('ABSPATH')) { exit; }

class NDM_Shortcodes {
    public function __construct() {
        add_shortcode('download', array($this, 'render_download_form'));
        add_shortcode('nas_download', array($this, 'render_download_form'));
    }

    public function render_download_form($atts) {
        $atts = shortcode_atts(array('title' => 'Download'), (array) $atts);

        if (!empty($_GET['ndm_download']) && !empty($_GET['code']) && class_exists('NDM_Download')) {
            NDM_Download::handle_request();
        }
 
        $current_url = get_permalink();
        if (empty($current_url)) {
            $current_url = home_url(add_query_arg(array(), $_SERVER['REQUEST_URI']));
        }
        $current_url = esc_url($current_url);
        $html = '<form method="get" action="' . $current_url . '">';
        $html .= '<input type="hidden" name="ndm_download" value="1">';
        $html .= '<p><label>Downloadcode: <input type="text" name="code"></label></p>';
        $html .= '<p><button type="submit">' . esc_html($atts['title']) . ' starten</button></p>';
        $html .= '</form>';

        return $html;
    }
}
