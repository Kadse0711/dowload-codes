<?php
if (!defined('ABSPATH')) { exit; }

class NDM_Database {
    public static function table($name) {
        global $wpdb;
        if ($name === 'logs') {
            return $wpdb->prefix . 'ndm_download_logs';
        }
        if ($name === 'uploads') {
            return $wpdb->prefix . 'ndm_download_uploads';
        }
        return $wpdb->prefix . 'ndm_downloads';
    }

    public static function install() {
        global $wpdb;
        $codes_table = self::table('codes');
        $logs_table = self::table('logs');
        $uploads_table = self::table('uploads');
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE {$codes_table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            code VARCHAR(100) NOT NULL,
            files LONGTEXT NOT NULL,
            email VARCHAR(255) DEFAULT NULL,
            expires_at DATETIME NULL,
            max_downloads INT DEFAULT 0,
            downloads INT DEFAULT 0,
            status VARCHAR(20) DEFAULT 'active',
            last_sent DATETIME NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY code (code)
        ) {$charset_collate};
        CREATE TABLE {$logs_table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            code_id BIGINT UNSIGNED DEFAULT NULL,
            code VARCHAR(100) DEFAULT NULL,
            file_path VARCHAR(1024) DEFAULT NULL,
            user_id BIGINT UNSIGNED DEFAULT NULL,
            ip VARCHAR(45) DEFAULT NULL,
            user_agent VARCHAR(1024) DEFAULT NULL,
            success TINYINT(1) DEFAULT 0,
            message TEXT DEFAULT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY code_id (code_id)
        ) {$charset_collate};
        CREATE TABLE {$uploads_table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            file_name VARCHAR(255) NOT NULL,
            file_path VARCHAR(1024) NOT NULL,
            file_size BIGINT UNSIGNED DEFAULT 0,
            upload_method VARCHAR(20) DEFAULT NULL,
            uploader_id BIGINT UNSIGNED DEFAULT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) {$charset_collate};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    public static function prepare_code_data($row) {
        if (!$row) { return null; }
        $row = (array) $row;
        $files = json_decode($row['files'], true);
        $row['files'] = self::normalize_files($files);
        if (isset($row['expires_at'])) { $row['expires'] = $row['expires_at']; }
        if (isset($row['created_at'])) { $row['created'] = $row['created_at']; }
        return $row;
    }

    public static function normalize_files($files) {
        if (empty($files)) {
            return array();
        }
        if (!is_array($files)) {
            $files = array($files);
        }

        $normalized = array();
        foreach ($files as $file) {
            if (is_string($file)) {
                $url = $file;
                $name = self::get_default_file_name($url);
                $normalized[] = array('url' => $url, 'name' => $name);
                continue;
            }
            if (!is_array($file)) {
                continue;
            }

            $url = '';
            if (isset($file['url'])) {
                $url = $file['url'];
            } elseif (isset($file['path'])) {
                $url = $file['path'];
            } elseif (isset($file['file'])) {
                $url = $file['file'];
            } elseif (isset($file['link'])) {
                $url = $file['link'];
            }

            if (empty($url)) {
                continue;
            }

            $name = '';
            if (isset($file['name'])) {
                $name = $file['name'];
            } elseif (isset($file['display_name'])) {
                $name = $file['display_name'];
            } elseif (isset($file['label'])) {
                $name = $file['label'];
            }

            $normalized[] = array(
                'url' => $url,
                'name' => trim(sanitize_text_field($name)) !== '' ? trim(sanitize_text_field($name)) : self::get_default_file_name($url),
            );
        }

        return $normalized;
    }

    public static function get_file_url($file) {
        if (is_string($file)) {
            return $file;
        }
        if (!is_array($file)) {
            return '';
        }
        if (isset($file['url'])) {
            return $file['url'];
        }
        if (isset($file['path'])) {
            return $file['path'];
        }
        if (isset($file['file'])) {
            return $file['file'];
        }
        if (isset($file['link'])) {
            return $file['link'];
        }
        return '';
    }

    public static function get_file_name($file) {
        if (is_string($file)) {
            return self::get_default_file_name($file);
        }
        if (!is_array($file)) {
            return '';
        }
        if (!empty($file['name'])) {
            return sanitize_text_field($file['name']);
        }
        if (!empty($file['display_name'])) {
            return sanitize_text_field($file['display_name']);
        }
        if (!empty($file['label'])) {
            return sanitize_text_field($file['label']);
        }
        return self::get_default_file_name(self::get_file_url($file));
    }

    protected static function get_default_file_name($url) {
        $url = preg_replace('#^local:#i', '', (string) $url);
        $path = parse_url($url, PHP_URL_PATH);
        $file_name = basename($path ?: $url);
        $file_name = sanitize_file_name($file_name);
        if ($file_name === '') {
            $file_name = 'Download';
        }
        return $file_name;
    }

    public static function create_code($data) {
        global $wpdb;
        $table = self::table('codes');
        $files = self::normalize_files(isset($data['files']) ? $data['files'] : array());
        $fields = array(
            'code' => sanitize_text_field(isset($data['code']) ? $data['code'] : ''),
            'files' => wp_json_encode($files),
            'email' => !empty($data['email']) ? sanitize_email($data['email']) : null,
            'expires_at' => !empty($data['expires_at']) ? sanitize_text_field($data['expires_at']) : (!empty($data['expires']) ? sanitize_text_field($data['expires']) : null),
            'max_downloads' => isset($data['max_downloads']) ? intval($data['max_downloads']) : 0,
            'status' => !empty($data['status']) ? sanitize_text_field($data['status']) : 'active',
            'last_sent' => !empty($data['last_sent']) ? sanitize_text_field($data['last_sent']) : null,
        );
        $formats = array('%s','%s','%s','%s','%d','%s','%s');
        $wpdb->insert($table, $fields, $formats);
        return $wpdb->insert_id;
    }

    public static function update_code($id, $data) {
        global $wpdb;
        $table = self::table('codes');
        $fields = array();
        $formats = array();
        foreach ($data as $key => $value) {
            if ($key === 'files') { $fields['files'] = wp_json_encode(self::normalize_files($value)); $formats[] = '%s'; }
            elseif ($key === 'code') { $fields['code'] = sanitize_text_field($value); $formats[] = '%s'; }
            elseif ($key === 'email') { $fields['email'] = !empty($value) ? sanitize_email($value) : null; $formats[] = '%s'; }
            elseif ($key === 'expires_at' || $key === 'expires') { $fields['expires_at'] = !empty($value) ? sanitize_text_field($value) : null; $formats[] = '%s'; }
            elseif ($key === 'max_downloads') { $fields['max_downloads'] = intval($value); $formats[] = '%d'; }
            elseif ($key === 'downloads') { $fields['downloads'] = intval($value); $formats[] = '%d'; }
            elseif ($key === 'status') { $fields['status'] = sanitize_text_field($value); $formats[] = '%s'; }
            elseif ($key === 'last_sent') { $fields['last_sent'] = !empty($value) ? sanitize_text_field($value) : null; $formats[] = '%s'; }
        }
        if (empty($fields)) { return false; }
        return $wpdb->update($table, $fields, array('id' => intval($id)), $formats, array('%d')) !== false;
    }

    public static function get_code_by_code($code) {
        global $wpdb;
        $table = self::table('codes');
        $sql = $wpdb->prepare('SELECT * FROM ' . $table . ' WHERE code = %s LIMIT 1', sanitize_text_field($code));
        return self::prepare_code_data($wpdb->get_row($sql));
    }

    public static function get_code_by_id($id) {
        global $wpdb;
        $table = self::table('codes');
        $sql = $wpdb->prepare('SELECT * FROM ' . $table . ' WHERE id = %d LIMIT 1', intval($id));
        return self::prepare_code_data($wpdb->get_row($sql));
    }

    public static function list_codes($limit, $offset) {
        global $wpdb;
        $table = self::table('codes');
        $sql = $wpdb->prepare('SELECT * FROM ' . $table . ' ORDER BY created_at DESC LIMIT %d OFFSET %d', intval($limit), intval($offset));
        $rows = $wpdb->get_results($sql);
        $items = array();
        foreach ($rows as $row) { $code = self::prepare_code_data($row); if (!is_array($code['files'])) { $code['files'] = array(); } $items[] = $code; }
        return $items;
    }

    public static function create_upload($data) {
        global $wpdb;
        $table = self::table('uploads');
        $fields = array(
            'file_name' => sanitize_text_field(isset($data['file_name']) ? $data['file_name'] : ''),
            'file_path' => sanitize_text_field(isset($data['file_path']) ? $data['file_path'] : ''),
            'file_size' => isset($data['file_size']) ? intval($data['file_size']) : 0,
            'upload_method' => sanitize_text_field(isset($data['upload_method']) ? $data['upload_method'] : ''),
            'uploader_id' => isset($data['uploader_id']) ? intval($data['uploader_id']) : null,
        );
        $formats = array('%s', '%s', '%d', '%s', '%d');
        $wpdb->insert($table, $fields, $formats);
        return $wpdb->insert_id;
    }

    public static function list_uploads($limit, $offset) {
        global $wpdb;
        $table = self::table('uploads');
        $sql = $wpdb->prepare('SELECT * FROM ' . $table . ' ORDER BY created_at DESC LIMIT %d OFFSET %d', intval($limit), intval($offset));
        $rows = $wpdb->get_results($sql, ARRAY_A);
        if (!is_array($rows)) {
            $rows = array();
        }
        return $rows;
    }

    public static function get_upload_by_id($id) {
        global $wpdb;
        $table = self::table('uploads');
        $sql = $wpdb->prepare('SELECT * FROM ' . $table . ' WHERE id = %d LIMIT 1', intval($id));
        return $wpdb->get_row($sql, ARRAY_A);
    }

    public static function count_uploads() {
        global $wpdb;
        $table = self::table('uploads');
        return intval($wpdb->get_var('SELECT COUNT(*) FROM ' . $table));
    }

    public static function incr_downloads($id) {
        global $wpdb;
        $table = self::table('codes');
        return $wpdb->query($wpdb->prepare('UPDATE ' . $table . ' SET downloads = downloads + 1 WHERE id = %d', intval($id)));
    }

    public static function delete_code($id) {
        global $wpdb;
        $table = self::table('codes');
        return $wpdb->delete($table, array('id' => intval($id)), array('%d')) !== false;
    }

    public static function delete_upload($id) {
        global $wpdb;
        $table = self::table('uploads');
        return $wpdb->delete($table, array('id' => intval($id)), array('%d')) !== false;
    }

    public static function log_download($data) {
        global $wpdb;
        $table = self::table('logs');
        $fields = array(
            'code_id' => isset($data['code_id']) ? intval($data['code_id']) : null,
            'code' => isset($data['code']) ? sanitize_text_field($data['code']) : null,
            'file_path' => isset($data['file_path']) ? sanitize_text_field($data['file_path']) : null,
            'user_id' => isset($data['user_id']) ? intval($data['user_id']) : null,
            'ip' => isset($data['ip']) ? sanitize_text_field($data['ip']) : null,
            'user_agent' => isset($data['user_agent']) ? sanitize_text_field($data['user_agent']) : null,
            'success' => isset($data['success']) ? intval($data['success']) : 0,
            'message' => isset($data['message']) ? sanitize_text_field($data['message']) : null,
        );
        $formats = array('%d','%s','%s','%d','%s','%s','%d','%s');
        $wpdb->insert($table, $fields, $formats);
        return $wpdb->insert_id;
    }

    public static function list_logs($limit, $offset) {
        global $wpdb;
        $table = self::table('logs');
        $sql = $wpdb->prepare('SELECT * FROM ' . $table . ' ORDER BY created_at DESC LIMIT %d OFFSET %d', intval($limit), intval($offset));
        $rows = $wpdb->get_results($sql, ARRAY_A);
        if (!is_array($rows)) { $rows = array(); }
        foreach ($rows as &$row) { if (isset($row['created_at'])) { $row['created'] = $row['created_at']; } }
        unset($row);
        return $rows;
    }

    public static function count_active_codes() { global $wpdb; $table = self::table('codes'); return intval($wpdb->get_var('SELECT COUNT(*) FROM ' . $table . ' WHERE status = "active"')); }
    public static function count_codes() { global $wpdb; $table = self::table('codes'); return intval($wpdb->get_var('SELECT COUNT(*) FROM ' . $table)); }
    public static function count_logs_since($hours) { global $wpdb; $table = self::table('logs'); $timestamp = current_time('timestamp'); $since = date('Y-m-d H:i:s', intval($timestamp - intval($hours) * 3600)); return intval($wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM ' . $table . ' WHERE created_at >= %s', $since))); }

    public static function top_files($limit) { global $wpdb; $table = self::table('logs'); $sql = $wpdb->prepare('SELECT file_path, COUNT(*) AS downloads FROM ' . $table . ' WHERE success = 1 AND file_path != "" GROUP BY file_path ORDER BY downloads DESC LIMIT %d', intval($limit)); return $wpdb->get_results($sql, ARRAY_A); }
    public static function top_codes($limit) { global $wpdb; $table = self::table('logs'); $sql = $wpdb->prepare('SELECT code, COUNT(*) AS downloads FROM ' . $table . ' WHERE success = 1 AND code != "" GROUP BY code ORDER BY downloads DESC LIMIT %d', intval($limit)); return $wpdb->get_results($sql, ARRAY_A); }
}
