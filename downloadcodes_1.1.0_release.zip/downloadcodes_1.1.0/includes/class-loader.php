<?php
if (!defined('ABSPATH')) { exit; }

require_once NDM_PLUGIN_PATH . 'includes/class-database.php';
require_once NDM_PLUGIN_PATH . 'includes/class-security.php';
require_once NDM_PLUGIN_PATH . 'includes/class-uploader.php';
require_once NDM_PLUGIN_PATH . 'includes/class-download.php';
require_once NDM_PLUGIN_PATH . 'includes/class-shortcodes.php';
require_once NDM_PLUGIN_PATH . 'includes/helper.php';
require_once NDM_PLUGIN_PATH . 'admin/class-admin.php';

class NDM_Loader {
    protected static $handled_download = false;

    public static function activate() {
        if (class_exists('NDM_Database')) {
            NDM_Database::install();
            flush_rewrite_rules();
        }
    }

    public static function deactivate() {
        flush_rewrite_rules();
    }

    public static function register_rewrite_rules() {
        add_rewrite_rule('^download/([^/]+)/all/?$', 'index.php?ndm_download=1&code=$matches[1]&file=all', 'top');
        add_rewrite_rule('^download/([^/]+)/([0-9]+)/?$', 'index.php?ndm_download=1&code=$matches[1]&file=$matches[2]', 'top');
        add_rewrite_rule('^download/([^/]+)/?$', 'index.php?ndm_download=1&code=$matches[1]', 'top');
    }

    public static function add_query_vars($vars) {
        $vars[] = 'ndm_download';
        $vars[] = 'code';
        $vars[] = 'file';
        return $vars;
    }

    public static function init() {
        add_action('init', array('NDM_Loader', 'register_rewrite_rules'));
        add_filter('query_vars', array('NDM_Loader', 'add_query_vars'));
        add_action('parse_request', array('NDM_Loader', 'handle_download_request'));
        add_action('template_redirect', array('NDM_Loader', 'handle_download_request'));
 
        if (is_admin() && class_exists('NDM_Admin')) {
            new NDM_Admin();
        }

        if (class_exists('NDM_Shortcodes')) {
            new NDM_Shortcodes();
        }
    }

    public static function handle_download_request() {
        if (self::$handled_download) {
            return;
        }

        $ndm_download = false;
        if (!empty($_GET['ndm_download'])) {
            $ndm_download = true;
        } elseif (function_exists('get_query_var') && get_query_var('ndm_download')) {
            $ndm_download = true;
        }
 
        if ($ndm_download && class_exists('NDM_Download')) {
            self::$handled_download = true;
            NDM_Download::handle_request();
        }
    }
}
