<?php
if (!defined('ABSPATH')) {
    exit;
}

class NDM_Admin {
    public function __construct() {
        add_action('admin_menu', array($this, 'register_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_assets'));
        add_action('admin_post_ndm_save_settings', array($this, 'save_settings'));
        add_action('admin_post_ndm_save_code', array($this, 'save_code'));
        add_action('admin_post_ndm_delete_code', array($this, 'delete_code'));
        add_action('admin_post_ndm_toggle_code_status', array($this, 'toggle_code_status'));
    }

    public function register_menu() {
        add_menu_page('NAS Download Manager', 'NAS Downloads', 'manage_options', 'nas-download-manager', array($this, 'dashboard_page'), 'dashicons-download', 25);
        add_submenu_page('nas-download-manager', 'Dashboard', 'Dashboard', 'manage_options', 'nas-download-manager', array($this, 'dashboard_page'));
        add_submenu_page('nas-download-manager', 'Download-Codes', 'Download-Codes', 'manage_options', 'ndm-codes', array($this, 'codes_page'));
        add_submenu_page('nas-download-manager', 'Logs', 'Logs', 'manage_options', 'ndm-logs', array($this, 'logs_page'));
        add_submenu_page('nas-download-manager', 'Einstellungen', 'Einstellungen', 'manage_options', 'ndm-settings', array($this, 'settings_page'));
        add_submenu_page('nas-download-manager', 'Hilfe', 'Hilfe', 'manage_options', 'ndm-help', array($this, 'help_page'));
    }

    public function enqueue_assets($hook) {
        if (strpos($hook, 'nas-download-manager') === false && strpos($hook, 'ndm-') === false) {
            return;
        }
        wp_enqueue_style('ndm-admin-style', NDM_PLUGIN_URL . 'assets/css/admin.css', array(), NDM_VERSION);
        wp_enqueue_script('ndm-admin-script', NDM_PLUGIN_URL . 'assets/js/admin.js', array('jquery'), NDM_VERSION, true);
    }

    public function dashboard_page() {
        if (!current_user_can('manage_options')) {
            return;
        }

        $active_codes = NDM_Database::count_active_codes();
        $downloads_today = NDM_Database::count_logs_since(24);
        $latest_logs = NDM_Database::list_logs(8, 0);
        ?>
        <div class="wrap ndm-admin-page">
            <h1>NAS Download Manager</h1>
            <div class="ndm-dashboard-grid">
                <div class="ndm-card ndm-card-status">
                    <h2>Status</h2>
                    <p>Aktive Codes: <?php echo esc_html($active_codes); ?></p>
                    <p>Downloads heute: <?php echo esc_html($downloads_today); ?></p>
                </div>
                <div class="ndm-card ndm-card-info">
                    <h2>Arbeitsweise</h2>
                    <p>Dieses Plugin nutzt direkte Remote-Links oder Dateien im internen Speicher.</p>
                    <p>Interne Dateien werden geschützt über den Downloadcode gestreamt.</p>
                </div>
            </div>

            <div class="ndm-card ndm-card-logs">
                <h2>Letzte Downloads</h2>
                <table class="widefat fixed striped">
                    <thead>
                        <tr>
                            <th>Datum</th>
                            <th>Code</th>
                            <th>Datei</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($latest_logs)) : ?>
                            <tr><td colspan="4">Keine Downloads vorhanden.</td></tr>
                        <?php else : ?>
                            <?php foreach ($latest_logs as $log) : ?>
                                <tr>
                                    <td><?php echo esc_html(isset($log['created_at']) ? $log['created_at'] : (isset($log['created']) ? $log['created'] : '')); ?></td>
                                    <td><?php echo esc_html($log['code']); ?></td>
                                    <td><?php echo esc_html($log['file_path']); ?></td>
                                    <td><?php echo empty($log['success']) ? 'Fehlgeschlagen' : 'Erfolgreich'; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="ndm-card ndm-card-logs">
                <h2>Kurzanleitung</h2>
                <ol>
                    <li>Erstelle unter <strong>Download-Codes</strong> einen Code und wähle einen Remote-Link oder eine interne Datei.</li>
                    <li>Füge den Shortcode <code>[download]</code> auf einer Seite ein, damit Empfänger den Code eingeben können.</li>
                    <li>Die Logs zeigen, welche Datei wann heruntergeladen wurde.</li>
                </ol>
            </div>
        </div>
        <?php
    }


    public function codes_page() {
        if (!current_user_can('manage_options')) {
            return;
        }

        $codes = NDM_Database::list_codes(100, 0);
        $notice = isset($_GET['ndm_notice']) ? sanitize_text_field($_GET['ndm_notice']) : '';
        ?>
        <div class="wrap ndm-admin-page">
            <h1>Download-Codes</h1>
            <?php if (!empty($notice)) : ?>
                <div class="notice notice-success"><p><?php echo esc_html($notice); ?></p></div>
            <?php endif; ?>

            <h2>Neuen Code erstellen</h2>
            <div class="ndm-card">
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" enctype="multipart/form-data">
                    <?php wp_nonce_field('ndm_save_code', 'ndm_nonce'); ?>
                    <input type="hidden" name="action" value="ndm_save_code">
                    <table class="form-table">
                        <tr>
                            <th><label for="recipient_email">Empfänger-E-Mail</label></th>
                            <td><input type="email" id="recipient_email" name="recipient_email" class="regular-text"></td>
                        </tr>
                        <tr>
                            <th><label for="email_template">E-Mail-Vorlage</label></th>
                            <td>
                                <select id="email_template" name="email_template" class="regular-text">
                                    <option value="">Standard</option>
                                    <?php $template_options = $this->get_available_email_templates(); foreach ($template_options as $template_key => $template_label) : ?>
                                        <option value="<?php echo esc_attr($template_key); ?>"><?php echo esc_html($template_label); ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <p class="description">Wähle eine der vordefinierten Vorlagen aus den Einstellungen.</p>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="custom_code">Code (optional)</label></th>
                            <td><input type="text" id="custom_code" name="custom_code" class="regular-text" placeholder="Leer = automatisch"></td>
                        </tr>
                        <tr>
                            <th><label for="expires">Ablaufdatum</label></th>
                            <td><input type="date" id="expires" name="expires"></td>
                        </tr>
                        <tr>
                            <th><label for="max_downloads">Max Downloads</label></th>
                            <td><input type="number" id="max_downloads" name="max_downloads" value="0"></td>
                        </tr>
                        <tr>
                            <th><label for="file_source">Dateiquelle</label></th>
                            <td>
                                <select id="file_source" name="file_source">
                                    <option value="remote">Remote-Link</option>
                                    <option value="internal">Interner Speicher</option>
                                </select>
                            </td>
                        </tr>
                        <tr id="remote_file_row">
                            <th><label for="remote_link">Remote-Link</label></th>
                            <td>
                                <input type="url" id="remote_link" name="remote_link" class="regular-text" placeholder="https://example.com/datei.pdf">
                                <p class="description">Bitte gib hier den direkten HTTPS-Link ein. Kein vorheriges Speichern eines Links erforderlich.</p>
                            </td>
                        </tr>
                        <tr id="internal_file_row" style="display:none;">
                            <th><label for="internal_file">Datei</label></th>
                            <td>
                                <input type="file" id="internal_file" name="internal_file">
                                <p class="description">Die Datei wird im konfigurierten internen Speicher abgelegt.</p>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="remote_name">Link-Bezeichnung (optional)</label></th>
                            <td>
                                <input type="text" id="remote_name" name="remote_name" class="regular-text" placeholder="z. B. Produktvideo">
                                <p class="description">Diese Bezeichnung erscheint in der E-Mail statt der URL.</p>
                            </td>
                        </tr>
                    </table>
                    <p><button class="button button-primary" type="submit">Code erstellen</button></p>
                </form>
            </div>

            <h2>Bestehende Codes</h2>
            <table class="widefat fixed striped ndm-codes-table">
                <thead>
                    <tr>
                        <th>Code</th>
                        <th>Dateien</th>
                        <th>Ablauf</th>
                        <th>Downloads</th>
                        <th>Status</th>
                        <th>Aktionen</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($codes)) : ?>
                        <tr><td colspan="6">Keine Codes gefunden.</td></tr>
                    <?php else : ?>
                        <?php foreach ($codes as $code) : ?>
                            <tr>
                                <td><?php echo esc_html($code['code']); ?></td>
                                <td>
                                    <?php $display_files = array(); foreach ($code['files'] as $file_entry) { $display_files[] = NDM_Database::get_file_name($file_entry); } ?>
                                    <?php echo esc_html(implode(', ', $display_files)); ?>
                                </td>
                                <td><?php echo esc_html(!empty($code['expires_at']) ? $code['expires_at'] : 'Nie'); ?></td>
                                <td><?php echo esc_html(intval($code['downloads'])) . ' / ' . esc_html(!empty($code['max_downloads']) ? intval($code['max_downloads']) : '∞'); ?></td>
                                <td><?php echo esc_html(ucfirst($code['status'])); ?></td>
                                <td>
                                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="ndm-inline-form">
                                        <?php wp_nonce_field('ndm_toggle_code_status', 'ndm_nonce'); ?>
                                        <input type="hidden" name="action" value="ndm_toggle_code_status">
                                        <input type="hidden" name="code_id" value="<?php echo esc_attr($code['id']); ?>">
                                        <button class="button button-secondary" type="submit"><?php echo esc_html($code['status'] === 'active' ? 'Deaktivieren' : 'Aktivieren'); ?></button>
                                    </form>
                                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="ndm-inline-form ndm-delete-form">
                                        <?php wp_nonce_field('ndm_delete_code', 'ndm_nonce'); ?>
                                        <input type="hidden" name="action" value="ndm_delete_code">
                                        <input type="hidden" name="code_id" value="<?php echo esc_attr($code['id']); ?>">
                                        <button class="button button-link-delete" type="submit" onclick="return confirm('Diesen Code wirklich löschen?');">Löschen</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    public function logs_page() {
        if (!current_user_can('manage_options')) {
            return;
        }

        $logs = NDM_Database::list_logs(200, 0);
        ?>
        <div class="wrap ndm-admin-page">
            <h1>Logs</h1>
            <table class="widefat fixed striped ndm-logs-table">
                <thead>
                    <tr>
                        <th>Datum</th>
                        <th>Code</th>
                        <th>Datei</th>
                        <th>Benutzer</th>
                        <th>IP</th>
                        <th>Status</th>
                        <th>Nachricht</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($logs)) : ?>
                        <tr><td colspan="7">Keine Logs vorhanden.</td></tr>
                    <?php else : ?>
                        <?php foreach ($logs as $log) : ?>
                            <tr>
                                <td><?php echo esc_html(isset($log['created_at']) ? $log['created_at'] : (isset($log['created']) ? $log['created'] : '')); ?></td>
                                <td><?php echo esc_html($log['code']); ?></td>
                                <td><?php echo esc_html($log['file_path']); ?></td>
                                <td><?php $user = !empty($log['user_id']) ? get_user_by('id', intval($log['user_id'])) : false; echo esc_html($user ? $user->display_name : 'Gast'); ?></td>
                                <td><?php echo esc_html($log['ip']); ?></td>
                                <td><?php echo empty($log['success']) ? 'Fehlgeschlagen' : 'Erfolgreich'; ?></td>
                                <td><?php echo esc_html($log['message']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    public function statistics_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
 
        $active_codes = NDM_Database::count_active_codes();
        $logs_total = NDM_Database::count_logs_since(999999);
        $top_files = NDM_Database::top_files(10);
        $top_codes = NDM_Database::top_codes(10);
        ?>
        <div class="wrap ndm-admin-page">
            <h1>Statistik</h1>
            <div class="ndm-dashboard-grid">
                <div class="ndm-card">
                    <h2>Übersicht</h2>
                    <p>Aktive Codes: <?php echo esc_html($active_codes); ?></p>
                    <p>Downloads insgesamt: <?php echo esc_html($logs_total); ?></p>
                </div>
                <div class="ndm-card">
                    <h2>Top Dateien</h2>
                    <ul>
                        <?php if (empty($top_files)) : ?>
                            <li>Keine Downloads.</li>
                        <?php else : ?>
                            <?php foreach ($top_files as $item) : ?>
                                <li><?php echo esc_html($item['file_path']); ?> (<?php echo esc_html($item['downloads']); ?>)</li>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </ul>
                </div>
                <div class="ndm-card">
                    <h2>Top Codes</h2>
                    <ul>
                        <?php if (empty($top_codes)) : ?>
                            <li>Keine Codes.</li>
                        <?php else : ?>
                            <?php foreach ($top_codes as $item) : ?>
                                <li><?php echo esc_html($item['code']); ?> (<?php echo esc_html($item['downloads']); ?>)</li>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
        <?php
    }

    public function help_page() {
        if (!current_user_can('manage_options')) {
            return;
        }

        ?>
        <div class="wrap ndm-admin-page">
            <h1>Hilfe</h1>
            <p>Dieses Plugin ermöglicht Downloadcodes für Remote-URLs und Dateien im internen Speicher.</p>
            <h2>So verwendest du das Plugin</h2>
            <ol>
                <li>Erstelle unter <strong>Download-Codes</strong> einen Code und gib dort den direkten HTTPS-Link ein.</li>
                <li>Der Empfänger kann den Code auf der Frontend-Seite mit dem Shortcode <code>[download]</code> eingeben.</li>
                <li>Die Logs zeigen dir, welche Codes und Dateien heruntergeladen wurden.</li>
            </ol>
            <h2>Shortcode</h2>
            <p>Füge auf einer Seite folgenden Shortcode ein: <code>[download]</code>.</p>
            <h2>Platzhalter für E-Mail</h2>
            <ul>
                <li><code>{code}</code> - der Downloadcode</li>
                <li><code>{url}</code> - die Downloadseite</li>
                <li><code>{files}</code> - die zugewiesenen Dateinamen</li>
            </ul>
            <p>Unter <strong>Einstellungen</strong> kannst du zwei benannte E-Mail-Vorlagen anlegen. Beim Erstellen eines Codes kannst du dann direkt eine Vorlage auswählen.</p>
            <p>Bei der Code-Erstellung kannst du optional eigene Bezeichnungen pro Datei vergeben. Diese erscheinen dann in der E-Mail statt der rohen URL.</p>
        </div>
        <?php
    }

    public function settings_page() {
        if (!current_user_can('manage_options')) {
            return;
        }

        $download_page_url = get_option('ndm_download_page_url', '');
        $sender_name = get_option('ndm_sender_name', get_bloginfo('name'));
        $sender_email = get_option('ndm_sender_email', get_bloginfo('admin_email'));
        $email_subject = get_option('ndm_email_subject', 'Dein Downloadcode');
        $email_body = get_option('ndm_email_body', "Hier ist dein Downloadcode: {code}\n\nDu kannst ihn hier eingeben: {url}\n\nDateien:\n{files}");
        $send_as_html = get_option('ndm_email_html', '0') === '1';
        $email_template_1_name = get_option('ndm_email_template_1_name', 'Vorlage 1');
        $email_template_1_subject = get_option('ndm_email_template_1_subject', 'Dein Downloadcode');
        $email_template_1_body = get_option('ndm_email_template_1_body', "Hallo,\n\nHier ist dein Downloadcode: {code}\n\nKlicke hier, um ihn einzulösen: {url}\n\nDateien:\n{files}");
        $email_template_2_name = get_option('ndm_email_template_2_name', 'Vorlage 2');
        $email_template_2_subject = get_option('ndm_email_template_2_subject', 'Dein Downloadcode');
        $email_template_2_body = get_option('ndm_email_template_2_body', "Hallo,\n\nDein Downloadlink ist bereit.\n\nCode: {code}\n\nDownloadseite: {url}\n\nDateien:\n{files}");

        if (!empty($_GET['ndm_notice'])) {
            echo '<div class="notice notice-success is-dismissible"><p>' . esc_html(sanitize_text_field($_GET['ndm_notice'])) . '</p></div>';
        }
        ?>
        <div class="wrap ndm-admin-page">
            <h1>Einstellungen</h1>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <?php wp_nonce_field('ndm_save_settings', 'ndm_nonce'); ?>
                <input type="hidden" name="action" value="ndm_save_settings">
                <table class="form-table">
                    <tr>
                        <th><label for="ndm_internal_storage_root">Interner Speicherpfad</label></th>
                        <td><input type="text" id="ndm_internal_storage_root" name="ndm_internal_storage_root" class="regular-text" value="<?php echo esc_attr(get_option('ndm_internal_storage_root', '')); ?>"><p class="description">Optionaler absoluter Pfad zum KAS-Mount. Leer = WordPress-Uploadverzeichnis.</p></td>
                    </tr>
                    <tr>
                        <th><label for="ndm_download_page_url">Download-Seite</label></th>
                        <td><input type="url" id="ndm_download_page_url" name="ndm_download_page_url" class="regular-text" value="<?php echo esc_attr($download_page_url); ?>"><p class="description">Vollständige URL zur Seite mit dem Shortcode <code>[download]</code>. Beispiel: https://example.com/download</p></td>
                    </tr>
                    <tr>
                        <th><label for="ndm_sender_name">Absendername</label></th>
                        <td><input type="text" id="ndm_sender_name" name="ndm_sender_name" class="regular-text" value="<?php echo esc_attr($sender_name); ?>"></td>
                    </tr>
                    <tr>
                        <th><label for="ndm_sender_email">Absender-E-Mail</label></th>
                        <td><input type="email" id="ndm_sender_email" name="ndm_sender_email" class="regular-text" value="<?php echo esc_attr($sender_email); ?>"></td>
                    </tr>
                    <tr>
                        <th><label for="ndm_email_subject">E-Mail Betreff</label></th>
                        <td><input type="text" id="ndm_email_subject" name="ndm_email_subject" class="regular-text" value="<?php echo esc_attr($email_subject); ?>"></td>
                    </tr>
                    <tr>
                        <th><label for="ndm_email_body">E-Mail Text</label></th>
                        <td><textarea id="ndm_email_body" name="ndm_email_body" class="large-text" rows="6"><?php echo esc_textarea($email_body); ?></textarea><p class="description">Platzhalter: {code}, {url}, {files}</p></td>
                    </tr>
                    <tr>
                       <th><label for="ndm_email_template_1_name">Vorlage 1 Name</label></th>
                       <td><input type="text" id="ndm_email_template_1_name" name="ndm_email_template_1_name" class="regular-text" value="<?php echo esc_attr($email_template_1_name); ?>"></td>
                    </tr>
                    <tr>
                       <th><label for="ndm_email_template_1_subject">Vorlage 1 Betreff</label></th>
                       <td><input type="text" id="ndm_email_template_1_subject" name="ndm_email_template_1_subject" class="regular-text" value="<?php echo esc_attr($email_template_1_subject); ?>"></td>
                    </tr>
                    <tr>
                       <th><label for="ndm_email_template_1_body">Vorlage 1 Text</label></th>
                       <td><textarea id="ndm_email_template_1_body" name="ndm_email_template_1_body" class="large-text" rows="6"><?php echo esc_textarea($email_template_1_body); ?></textarea></td>
                    </tr>
                    <tr>
                       <th><label for="ndm_email_template_2_name">Vorlage 2 Name</label></th>
                       <td><input type="text" id="ndm_email_template_2_name" name="ndm_email_template_2_name" class="regular-text" value="<?php echo esc_attr($email_template_2_name); ?>"></td>
                    </tr>
                    <tr>
                       <th><label for="ndm_email_template_2_subject">Vorlage 2 Betreff</label></th>
                       <td><input type="text" id="ndm_email_template_2_subject" name="ndm_email_template_2_subject" class="regular-text" value="<?php echo esc_attr($email_template_2_subject); ?>"></td>
                    </tr>
                    <tr>
                       <th><label for="ndm_email_template_2_body">Vorlage 2 Text</label></th>
                       <td><textarea id="ndm_email_template_2_body" name="ndm_email_template_2_body" class="large-text" rows="6"><?php echo esc_textarea($email_template_2_body); ?></textarea></td>
                    </tr>
                    <tr>
                       <th><label for="ndm_email_html">E-Mail als HTML</label></th>
                        <td><label><input type="checkbox" id="ndm_email_html" name="ndm_email_html" value="1" <?php checked($send_as_html, true); ?>> E-Mail als HTML senden</label></td>
                    </tr>
                </table>
                <p><button class="button button-primary" type="submit">Speichern</button></p>
            </form>
        </div>
        <?php
    }

    public function save_settings() {
        if (!current_user_can('manage_options') || empty($_POST['ndm_nonce']) || !wp_verify_nonce($_POST['ndm_nonce'], 'ndm_save_settings')) {
            wp_die('Zugriff verweigert.');
        }

        $download_page_url = isset($_POST['ndm_download_page_url']) ? esc_url_raw($_POST['ndm_download_page_url']) : '';
        $sender_name = sanitize_text_field(isset($_POST['ndm_sender_name']) ? $_POST['ndm_sender_name'] : get_bloginfo('name'));
        $sender_email = sanitize_email(isset($_POST['ndm_sender_email']) ? $_POST['ndm_sender_email'] : get_bloginfo('admin_email'));
        $email_subject = sanitize_text_field(isset($_POST['ndm_email_subject']) ? $_POST['ndm_email_subject'] : 'Dein Downloadcode');
        $email_body = wp_kses_post(isset($_POST['ndm_email_body']) ? $_POST['ndm_email_body'] : "Hier ist dein Downloadcode: {code}\n\nDu kannst ihn hier eingeben: {url}\n\nDateien:\n{files}");
        $email_template_1_name = sanitize_text_field(isset($_POST['ndm_email_template_1_name']) ? $_POST['ndm_email_template_1_name'] : 'Vorlage 1');
        $email_template_1_subject = sanitize_text_field(isset($_POST['ndm_email_template_1_subject']) ? $_POST['ndm_email_template_1_subject'] : 'Dein Downloadcode');
        $email_template_1_body = wp_kses_post(isset($_POST['ndm_email_template_1_body']) ? $_POST['ndm_email_template_1_body'] : "Hallo,\n\nHier ist dein Downloadcode: {code}\n\nKlicke hier, um ihn einzulösen: {url}\n\nDateien:\n{files}");
        $email_template_2_name = sanitize_text_field(isset($_POST['ndm_email_template_2_name']) ? $_POST['ndm_email_template_2_name'] : 'Vorlage 2');
        $email_template_2_subject = sanitize_text_field(isset($_POST['ndm_email_template_2_subject']) ? $_POST['ndm_email_template_2_subject'] : 'Dein Downloadcode');
        $email_template_2_body = wp_kses_post(isset($_POST['ndm_email_template_2_body']) ? $_POST['ndm_email_template_2_body'] : "Hallo,\n\nDein Downloadlink ist bereit.\n\nCode: {code}\n\nDownloadseite: {url}\n\nDateien:\n{files}");
        $email_html = isset($_POST['ndm_email_html']) && $_POST['ndm_email_html'] === '1' ? '1' : '0';

        update_option('ndm_download_page_url', $download_page_url);
        update_option('ndm_internal_storage_root', sanitize_text_field(isset($_POST['ndm_internal_storage_root']) ? $_POST['ndm_internal_storage_root'] : ''));
        update_option('ndm_sender_name', $sender_name);
        update_option('ndm_sender_email', $sender_email);
        update_option('ndm_email_subject', $email_subject);
        update_option('ndm_email_body', $email_body);
        update_option('ndm_email_html', $email_html);
        update_option('ndm_email_template_1_name', $email_template_1_name);
        update_option('ndm_email_template_1_subject', $email_template_1_subject);
        update_option('ndm_email_template_1_body', $email_template_1_body);
        update_option('ndm_email_template_2_name', $email_template_2_name);
        update_option('ndm_email_template_2_subject', $email_template_2_subject);
        update_option('ndm_email_template_2_body', $email_template_2_body);

        delete_option('ndm_upload_method');
        delete_option('ndm_download_root');
        delete_option('ndm_default_upload_path');
        delete_option('ndm_ftp_host');
        delete_option('ndm_ftp_port');
        delete_option('ndm_ftp_ssl');
        delete_option('ndm_ftp_username');
        delete_option('ndm_ftp_password');
        delete_option('ndm_ftp_root');
        delete_option('ndm_file_station_url');
        delete_option('ndm_file_station_username');
        delete_option('ndm_file_station_password');
        delete_option('ndm_file_station_root');

        wp_redirect(add_query_arg(array('page' => 'ndm-settings', 'ndm_notice' => 'Einstellungen gespeichert.'), admin_url('admin.php')));
        exit;
    }



    public function save_code() {
        if (!current_user_can('manage_options') || empty($_POST['ndm_nonce']) || !wp_verify_nonce($_POST['ndm_nonce'], 'ndm_save_code')) {
            wp_die('Zugriff verweigert.');
        }

        $file_source = isset($_POST['file_source']) ? sanitize_key($_POST['file_source']) : 'remote';
        $remote_link = isset($_POST['remote_link']) ? trim($_POST['remote_link']) : '';
        $remote_name = isset($_POST['remote_name']) ? trim(sanitize_text_field($_POST['remote_name'])) : '';

        $files = array();
        if ($file_source === 'internal' && !empty($_FILES['internal_file']['name'])) {
            $upload = NDM_Uploader::upload_file($_FILES['internal_file'], '');
            if (!is_wp_error($upload)) {
                $files[] = array('url' => $upload, 'name' => $remote_name !== '' ? $remote_name : sanitize_file_name($_FILES['internal_file']['name']));
            }
        } elseif (!empty($remote_link) && filter_var($remote_link, FILTER_VALIDATE_URL) && preg_match('#^https?://#i', $remote_link)) {
            $remote_link = esc_url_raw($remote_link);
            $files[] = array(
                'url' => $remote_link,
                'name' => $remote_name,
            );
        }

        $recipient_email = null;
        if (!empty($_POST['recipient_email'])) {
            $recipient_email = sanitize_email($_POST['recipient_email']);
            if (!is_email($recipient_email)) {
                wp_redirect(add_query_arg(array('page' => 'ndm-codes', 'ndm_notice' => 'Ungültige Empfänger-E-Mail.'), admin_url('admin.php')));
                exit;
            }
        }

        $email_template = sanitize_text_field(isset($_POST['email_template']) ? $_POST['email_template'] : '');
        $custom_code = trim(sanitize_text_field(isset($_POST['custom_code']) ? $_POST['custom_code'] : ''));
        $expires = !empty($_POST['expires']) ? sanitize_text_field($_POST['expires']) : null;
        if (!empty($expires) && strtotime($expires) !== false) {
            $expires = $expires . ' 23:59:59';
        } else {
            $expires = null;
        }
        $max_downloads = isset($_POST['max_downloads']) ? max(0, intval($_POST['max_downloads'])) : 0;

        if (empty($files)) {
            wp_redirect(add_query_arg(array('page' => 'ndm-codes', 'ndm_notice' => 'Bitte wähle eine gültige Remote-URL oder interne Datei.'), admin_url('admin.php')));
            exit;
        }

        if (!empty($custom_code)) {
            $custom_code = $this->format_download_code($custom_code);
            if (empty($custom_code)) {
                do {
                    $custom_code = $this->generate_download_code();
                } while (NDM_Database::get_code_by_code($custom_code));
            } elseif (NDM_Database::get_code_by_code($custom_code)) {
                wp_redirect(add_query_arg(array('page' => 'ndm-codes', 'ndm_notice' => 'Der Code existiert bereits.'), admin_url('admin.php')));
                exit;
            }
        } else {
            do {
                $custom_code = $this->generate_download_code();
            } while (NDM_Database::get_code_by_code($custom_code));
        }

        $code_id = NDM_Database::create_code(array(
            'code' => $custom_code,
            'files' => $files,
            'email' => $recipient_email,
            'expires_at' => $expires,
            'max_downloads' => $max_downloads,
            'status' => 'active',
        ));

        $code_data = NDM_Database::get_code_by_id($code_id);
        if (!empty($recipient_email) && is_email($recipient_email) && $code_data) {
            $this->send_code_email($code_data, $recipient_email, $email_template);
        }

        wp_redirect(add_query_arg(array('page' => 'ndm-codes', 'ndm_notice' => 'Code erfolgreich erstellt.'), admin_url('admin.php')));
        exit;
    }

    public function delete_code() {
        if (!current_user_can('manage_options') || empty($_POST['ndm_nonce']) || !wp_verify_nonce($_POST['ndm_nonce'], 'ndm_delete_code')) {
            wp_die('Zugriff verweigert.');
        }

        $code_id = intval(isset($_POST['code_id']) ? $_POST['code_id'] : 0);
        NDM_Database::delete_code($code_id);
        wp_redirect(add_query_arg(array('page' => 'ndm-codes', 'ndm_notice' => 'Code gelöscht.'), admin_url('admin.php')));
        exit;
    }

    public function toggle_code_status() {
        if (!current_user_can('manage_options') || empty($_POST['ndm_nonce']) || !wp_verify_nonce($_POST['ndm_nonce'], 'ndm_toggle_code_status')) {
            wp_die('Zugriff verweigert.');
        }

        $code_id = intval(isset($_POST['code_id']) ? $_POST['code_id'] : 0);
        $code_data = NDM_Database::get_code_by_id($code_id);
        if (empty($code_data)) {
            wp_redirect(add_query_arg(array('page' => 'ndm-codes', 'ndm_notice' => 'Code nicht gefunden.'), admin_url('admin.php')));
            exit;
        }

        $new_status = ($code_data['status'] === 'active') ? 'inactive' : 'active';
        NDM_Database::update_code($code_id, array('status' => $new_status));
        wp_redirect(add_query_arg(array('page' => 'ndm-codes', 'ndm_notice' => ($new_status === 'active') ? 'Code aktiviert.' : 'Code deaktiviert.'), admin_url('admin.php')));
        exit;
    }

    protected function generate_download_code() {
        $raw = strtoupper(preg_replace('/[^A-Z0-9]/', '', wp_generate_password(12, false, false)));
        return $this->format_download_code($raw);
    }

    protected function format_download_code($code) {
        $code = strtoupper(preg_replace('/[^A-Z0-9]/', '', $code));
        $code = trim($code);
        $parts = str_split(substr($code, 0, 12), 4);
        return implode('-', $parts);
    }


    protected function get_available_email_templates() {
        $templates = array();
        $template_1_name = get_option('ndm_email_template_1_name', 'Vorlage 1');
        $template_2_name = get_option('ndm_email_template_2_name', 'Vorlage 2');
        if (!empty($template_1_name)) {
            $templates['template_1'] = sanitize_text_field($template_1_name);
        }
        if (!empty($template_2_name)) {
            $templates['template_2'] = sanitize_text_field($template_2_name);
        }
        return $templates;
    }

    protected function send_code_email($code_data, $recipient_email, $template_key = '') {
        $subject = get_option('ndm_email_subject', 'Dein Downloadcode');
        $body = get_option('ndm_email_body', "Hier ist dein Downloadcode: {code}\n\nDu kannst ihn hier eingeben: {url}\n\nDateien:\n{files}");
        $send_as_html = get_option('ndm_email_html', '0') === '1';
        $sender_name = get_option('ndm_sender_name', get_bloginfo('name'));
        $sender_email = get_option('ndm_sender_email', get_bloginfo('admin_email'));

        if ($template_key === 'template_1') {
            $subject = get_option('ndm_email_template_1_subject', $subject);
            $body = get_option('ndm_email_template_1_body', $body);
        } elseif ($template_key === 'template_2') {
            $subject = get_option('ndm_email_template_2_subject', $subject);
            $body = get_option('ndm_email_template_2_body', $body);
        }

        $download_page_url = trim(get_option('ndm_download_page_url', ''));
        if (!empty($download_page_url) && filter_var($download_page_url, FILTER_VALIDATE_URL)) {
            $base_url = untrailingslashit($download_page_url);
        } else {
            $base_url = home_url('/');
        }
        $download_url = esc_url(add_query_arg(array('ndm_download' => 1, 'code' => $code_data['code']), $base_url));
        $files_text = '';
        if (!empty($code_data['files']) && is_array($code_data['files'])) {
            foreach ($code_data['files'] as $file) {
                $files_text .= '- ' . NDM_Database::get_file_name($file) . "\n";
            }
        }

        $replacements = array(
            '{code}' => $code_data['code'],
            '{url}' => $download_url,
            '{files}' => trim($files_text),
        );

        $subject = strtr($subject, $replacements);
        $body = strtr($body, $replacements);

        $headers = array();
        if (is_email($sender_email)) {
            $headers[] = 'From: ' . sanitize_text_field($sender_name) . ' <' . sanitize_email($sender_email) . '>';
        }
        if ($send_as_html) {
            $headers[] = 'Content-Type: text/html; charset=UTF-8';
            $body = wp_kses_post($body);
            $body = nl2br($body);
        } else {
            $body = strip_tags($body);
        }

        wp_mail($recipient_email, $subject, $body, $headers);
    }
}
