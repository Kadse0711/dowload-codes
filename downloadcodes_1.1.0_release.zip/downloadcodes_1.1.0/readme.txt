NAS Download Manager — Anleitung

Dieses Plugin unterstützt direkte HTTPS-Links und Dateien im internen Speicher. Der interne Speicher kann das WordPress-Uploadverzeichnis oder ein eingebundener KAS-/NAS-Pfad sein.

A) Direktlinks im Plugin nutzen
1. WP-Admin → NAS Downloads → Download-Codes
2. Gib im Formular einen direkten HTTPS-Link ein.
3. Du musst keine Links vorher irgendwo speichern.
4. Optional kannst du eine eigene Bezeichnung für den Link angeben. Diese erscheint dann in der E-Mail statt der rohen URL.
5. Der Empfänger kann den Code auf der Frontend-Seite mit dem Shortcode [download] eingeben. [nas_download] bleibt als alter Alias verfügbar.
6. Wenn nur ein Link hinterlegt ist, wird der Besucher direkt zur Remote-Datei weitergeleitet, ohne eine zusätzliche Download-Auswahlseite.
7. Unter Einstellungen kannst du zwei benannte E-Mail-Vorlagen anlegen und diese später direkt beim Erstellen eines Codes auswählen.

B) HTML-E-Mail-Templates im Plugin
- Du kannst HTML in das Textfeld „E-Mail Text“ der Einstellungen schreiben. Aktiviere zusätzlich die Option „E-Mail als HTML senden“.
- Unterstützte Platzhalter:
  {code}  → der Download-Code
  {url}   → die Downloadseite
  {files} → die Dateiliste

Beispiel HTML-Vorlage:

<html>
  <body>
   <h2>Dein Downloadcode</h2>
   <p>Hallo,</p>
   <p>Hier ist dein Downloadcode: <strong>{code}</strong></p>
   <p>Klicke hier, um ihn einzulösen: <a href="{url}">{url}</a></p>
   <h3>Dateien</h3>
   <p>{files}</p>
  </body>
</html>

C) Hinweise / Sicherheit
- Nutze nur HTTPS-URLs.
- Für interne Dateien kann unter Einstellungen ein absoluter Speicherpfad zum KAS-Mount hinterlegt werden.
- Wenn möglich, setze auf der Zielseite Ablaufdaten, Passwortschutz oder Download-Limits.
- Die Downloadcodes werden für die weitergeleiteten Remote-URLs protokolliert.
